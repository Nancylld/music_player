package com.example.music_player

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.IBinder
import android.provider.MediaStore
import android.view.View
import android.widget.SeekBar
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_main.*
import java.io.IOException
import kotlin.concurrent.thread
import android.service.*

const val MyReceiverAction="com.example.music_player.newmusic"
class MainActivity : AppCompatActivity() ,ServiceConnection{


    var binder:MusicService.MusicBinder?=null

    //lateinit var receiver: MusicService
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //val intentFilter = IntentFilter()
        //intentFilter.addAction(MyReceiverAction)
        //receiver = MusicService()
        //registerReceiver(receiver,intentFilter)

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),0)
        }else{
           // getMusicList()
            startMusicService()
        }
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(
               seekBar: SeekBar,
                progress: Int,
                fromUser: Boolean
            ){
                if(fromUser){
                    binder?.currentPosition=progress

                }
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {
                TODO("Not yet implemented")
            }

            override fun onStopTrackingTouch(p0: SeekBar?) {
                TODO("Not yet implemented")
            }
        })

        

    }




    fun startMusicService(){
        val intent= Intent(this,MusicService::class.java)
        intent.putExtra(MusicService.Commond,1)
        startService(intent)
        bindService(intent,this,Context.BIND_AUTO_CREATE)

    }
    fun onplay(v:View){
        val intent= Intent(this,MusicService::class.java)
        intent.putExtra(MusicService.Commond,1)
        startService(intent)

    }
    fun onpause(v:View){
        val intent= Intent(this,MusicService::class.java)
        intent.putExtra(MusicService.Commond,2)
        startService(intent)

    }
    fun onstop(v:View){
        val intent= Intent(this,MusicService::class.java)
        intent.putExtra(MusicService.Commond,3)
        startService(intent)

    }
    fun onnext(v:View){
        val intent= Intent(this,MusicService::class.java)
        intent.putExtra(MusicService.Commond,4)
        startService(intent)

    }
    fun onprev(v:View){
        val intent= Intent(this,MusicService::class.java)
        intent.putExtra(MusicService.Commond,5)
        startService(intent)

    }




    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

    }



    override fun onDestroy() {
        super.onDestroy()
        unbindService(this)

    }

    override fun onServiceDisconnected(p0: ComponentName?) {
       binder=null
    }

    override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
        binder = service as MusicService.MusicBinder
        thread {
            while (binder != null){
                Thread.sleep(1000)
                runOnUiThread{
                     seekBar.max = binder!!.duration
                     seekBar.progress =binder!!.currentPosition
                     textView2_nm.text=binder!!.musicName
                     textView_count.text="${binder!!.currentIndex+1}/${binder?.size}"
                }

            }
        }
    }

}